﻿
namespace asdbencebencexyz
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_haromfeletti = new System.Windows.Forms.Button();
            this.btn_random = new System.Windows.Forms.Button();
            this.btn_xertekhatar = new System.Windows.Forms.Button();
            this.btn_novekvo = new System.Windows.Forms.Button();
            this.btn_stat = new System.Windows.Forms.Button();
            this.btn_xertehatarkiir = new System.Windows.Forms.Button();
            this.btn_legkisebb = new System.Windows.Forms.Button();
            this.btn_otnelnagyobb = new System.Windows.Forms.Button();
            this.txt_ertekhatar = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.btn_atlag = new System.Windows.Forms.Button();
            this.btn_bevitel = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_vendeg = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txt_hazai = new System.Windows.Forms.TextBox();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // btn_haromfeletti
            // 
            this.btn_haromfeletti.Location = new System.Drawing.Point(18, 532);
            this.btn_haromfeletti.Name = "btn_haromfeletti";
            this.btn_haromfeletti.Size = new System.Drawing.Size(154, 64);
            this.btn_haromfeletti.TabIndex = 33;
            this.btn_haromfeletti.Text = "3 feletti gólszámokat";
            this.btn_haromfeletti.UseVisualStyleBackColor = true;
            this.btn_haromfeletti.Click += new System.EventHandler(this.btn_haromfeletti_Click);
            // 
            // btn_random
            // 
            this.btn_random.Location = new System.Drawing.Point(263, 430);
            this.btn_random.Name = "btn_random";
            this.btn_random.Size = new System.Drawing.Size(154, 64);
            this.btn_random.TabIndex = 32;
            this.btn_random.Text = "10 véletlen szám";
            this.btn_random.UseVisualStyleBackColor = true;
            this.btn_random.Click += new System.EventHandler(this.btn_random_Click);
            // 
            // btn_xertekhatar
            // 
            this.btn_xertekhatar.Location = new System.Drawing.Point(627, 99);
            this.btn_xertekhatar.Name = "btn_xertekhatar";
            this.btn_xertekhatar.Size = new System.Drawing.Size(154, 64);
            this.btn_xertekhatar.TabIndex = 31;
            this.btn_xertekhatar.Text = "Értékhatár bevitel";
            this.btn_xertekhatar.UseVisualStyleBackColor = true;
            // 
            // btn_novekvo
            // 
            this.btn_novekvo.Location = new System.Drawing.Point(17, 430);
            this.btn_novekvo.Name = "btn_novekvo";
            this.btn_novekvo.Size = new System.Drawing.Size(154, 64);
            this.btn_novekvo.TabIndex = 30;
            this.btn_novekvo.Text = "Növekvő sorrend";
            this.btn_novekvo.UseVisualStyleBackColor = true;
            this.btn_novekvo.Click += new System.EventHandler(this.btn_novekvo_Click);
            // 
            // btn_stat
            // 
            this.btn_stat.Location = new System.Drawing.Point(264, 323);
            this.btn_stat.Name = "btn_stat";
            this.btn_stat.Size = new System.Drawing.Size(154, 64);
            this.btn_stat.TabIndex = 29;
            this.btn_stat.Text = "Statisztika";
            this.btn_stat.UseVisualStyleBackColor = true;
            this.btn_stat.Click += new System.EventHandler(this.btn_stat_Click);
            // 
            // btn_xertehatarkiir
            // 
            this.btn_xertehatarkiir.Location = new System.Drawing.Point(17, 323);
            this.btn_xertehatarkiir.Name = "btn_xertehatarkiir";
            this.btn_xertehatarkiir.Size = new System.Drawing.Size(154, 64);
            this.btn_xertehatarkiir.TabIndex = 28;
            this.btn_xertehatarkiir.Text = "X értékhatár szerinti kiiratás";
            this.btn_xertehatarkiir.UseVisualStyleBackColor = true;
            this.btn_xertehatarkiir.Click += new System.EventHandler(this.btn_xertehatarkiir_Click);
            // 
            // btn_legkisebb
            // 
            this.btn_legkisebb.Location = new System.Drawing.Point(264, 206);
            this.btn_legkisebb.Name = "btn_legkisebb";
            this.btn_legkisebb.Size = new System.Drawing.Size(154, 64);
            this.btn_legkisebb.TabIndex = 27;
            this.btn_legkisebb.Text = "Legkisebb";
            this.btn_legkisebb.UseVisualStyleBackColor = true;
            this.btn_legkisebb.Click += new System.EventHandler(this.btn_legkisebb_Click);
            // 
            // btn_otnelnagyobb
            // 
            this.btn_otnelnagyobb.Location = new System.Drawing.Point(17, 206);
            this.btn_otnelnagyobb.Name = "btn_otnelnagyobb";
            this.btn_otnelnagyobb.Size = new System.Drawing.Size(154, 64);
            this.btn_otnelnagyobb.TabIndex = 26;
            this.btn_otnelnagyobb.Text = "5-nél nagyobb gólszám (db)";
            this.btn_otnelnagyobb.UseVisualStyleBackColor = true;
            this.btn_otnelnagyobb.Click += new System.EventHandler(this.btn_otnelnagyobb_Click);
            // 
            // txt_ertekhatar
            // 
            this.txt_ertekhatar.Location = new System.Drawing.Point(627, 37);
            this.txt_ertekhatar.Name = "txt_ertekhatar";
            this.txt_ertekhatar.Size = new System.Drawing.Size(154, 22);
            this.txt_ertekhatar.TabIndex = 25;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(624, 12);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(140, 17);
            this.label3.TabIndex = 24;
            this.label3.Text = "Értékhatár megadás:";
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 16;
            this.listBox1.Location = new System.Drawing.Point(928, 12);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(291, 548);
            this.listBox1.TabIndex = 23;
            // 
            // btn_atlag
            // 
            this.btn_atlag.Location = new System.Drawing.Point(264, 99);
            this.btn_atlag.Name = "btn_atlag";
            this.btn_atlag.Size = new System.Drawing.Size(154, 64);
            this.btn_atlag.TabIndex = 22;
            this.btn_atlag.Text = "Átlag";
            this.btn_atlag.UseVisualStyleBackColor = true;
            this.btn_atlag.Click += new System.EventHandler(this.btn_atlag_Click);
            // 
            // btn_bevitel
            // 
            this.btn_bevitel.Location = new System.Drawing.Point(17, 99);
            this.btn_bevitel.Name = "btn_bevitel";
            this.btn_bevitel.Size = new System.Drawing.Size(154, 64);
            this.btn_bevitel.TabIndex = 21;
            this.btn_bevitel.Text = "Bevitel";
            this.btn_bevitel.UseVisualStyleBackColor = true;
            this.btn_bevitel.Click += new System.EventHandler(this.btn_bevitel_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(261, 12);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 17);
            this.label2.TabIndex = 20;
            this.label2.Text = "Vendég:";
            // 
            // txt_vendeg
            // 
            this.txt_vendeg.Location = new System.Drawing.Point(263, 37);
            this.txt_vendeg.Name = "txt_vendeg";
            this.txt_vendeg.Size = new System.Drawing.Size(154, 22);
            this.txt_vendeg.TabIndex = 19;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(15, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(48, 17);
            this.label1.TabIndex = 18;
            this.label1.Text = "Hazai:";
            // 
            // txt_hazai
            // 
            this.txt_hazai.Location = new System.Drawing.Point(17, 37);
            this.txt_hazai.Name = "txt_hazai";
            this.txt_hazai.Size = new System.Drawing.Size(154, 22);
            this.txt_hazai.TabIndex = 17;
            // 
            // listBox2
            // 
            this.listBox2.FormattingEnabled = true;
            this.listBox2.ItemHeight = 16;
            this.listBox2.Location = new System.Drawing.Point(1288, 12);
            this.listBox2.Name = "listBox2";
            this.listBox2.Size = new System.Drawing.Size(229, 548);
            this.listBox2.TabIndex = 34;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1529, 785);
            this.Controls.Add(this.listBox2);
            this.Controls.Add(this.btn_haromfeletti);
            this.Controls.Add(this.btn_random);
            this.Controls.Add(this.btn_xertekhatar);
            this.Controls.Add(this.btn_novekvo);
            this.Controls.Add(this.btn_stat);
            this.Controls.Add(this.btn_xertehatarkiir);
            this.Controls.Add(this.btn_legkisebb);
            this.Controls.Add(this.btn_otnelnagyobb);
            this.Controls.Add(this.txt_ertekhatar);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.btn_atlag);
            this.Controls.Add(this.btn_bevitel);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txt_vendeg);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txt_hazai);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_haromfeletti;
        private System.Windows.Forms.Button btn_random;
        private System.Windows.Forms.Button btn_xertekhatar;
        private System.Windows.Forms.Button btn_novekvo;
        private System.Windows.Forms.Button btn_stat;
        private System.Windows.Forms.Button btn_xertehatarkiir;
        private System.Windows.Forms.Button btn_legkisebb;
        private System.Windows.Forms.Button btn_otnelnagyobb;
        private System.Windows.Forms.TextBox txt_ertekhatar;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Button btn_atlag;
        private System.Windows.Forms.Button btn_bevitel;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_vendeg;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txt_hazai;
        private System.Windows.Forms.ListBox listBox2;
    }
}

