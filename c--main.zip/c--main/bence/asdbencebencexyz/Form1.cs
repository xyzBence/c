﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace asdbencebencexyz
{
    public partial class Form1 : Form
    {
        int[] golok = new int[150];
        int db = -1;

        public Form1()
        {
            InitializeComponent();

            MessageBox.Show("Made by Bence", "https://github.com/xyzBence", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        /*private void KiirListaba(string szoveg)
        {
            listBox1.Items.Add(""); 
            listBox1.Items.Add(""); 
        }
        */

       



        // ---------------------beviteli rész--------------------------------------------
        private void btn_bevitel_Click(object sender, EventArgs e)
        {
            try //kivetelkezeles 
            {
                
                db++;
                int hazai = Convert.ToInt32(txt_hazai.Text);    //beolvas   
                int vendeg = Convert.ToInt32(txt_vendeg.Text);  //beolvas




                // 0 - 100 kozotti ellenorzes 
               /* if (hazai < 0 || hazai > 100)
                {
                    MessageBox.Show("A gól értéke 0 és 100 közötti érték lehet!", "Hiba", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return; 
                }

                if (vendeg < 0 || vendeg > 100)
                {
                    MessageBox.Show("A gól értéke 0 és 100 közötti érték lehet!", "Hiba", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return; 
                }
               */


                int all = vendeg + hazai;   // osszeadas
                golok[db] = all; //tombe bele rak
                listBox2.Items.Add(golok[db]); // kiirat listboxban
                txt_hazai.Clear(); 
                txt_vendeg.Clear(); //torol
            }
            catch (Exception ex) //kivetelkezeles 
            {
                MessageBox.Show($"Hiba az adatbevitel során: {ex.Message}", "Hiba", MessageBoxButtons.OK, MessageBoxIcon.Error); //kivetelkezeles; msg box hiba megjelenites
            }
        }
        private void btn_atlag_Click(object sender, EventArgs e)
        {
            if (db == -1) // ellenorzes ha nincs adat
            {
                MessageBox.Show("A tömb üres nincs mit számolni", "INFO:", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            int osszeg = 0;
            double atlag = 0;

            // osszegez
            for (int i = 0; i <= db; i++) 
            {
                osszeg += golok[i];
            }

            listBox1.Items.Add("Összeg: " + osszeg);

            // Átlag szamitasa
            atlag = (double)osszeg / (db + 1); //atlag kiszamolasa
            atlag = Math.Round(atlag, 2); // kerekítés 2 tizedesjegyre
            listBox1.Items.Add(""); //ures sor
            listBox1.Items.Add("Az átlag: " + atlag); //kiirat
        }



        // ---------------------ötnél nagyobbak
        private void btn_otnelnagyobb_Click(object sender, EventArgs e)
        {
            int otneltobb = 0;

            for (int i = 0; i <= db; i++) //otnel tobb kikeres
            {
                if (golok[i] > 5) //ha otnel tobb
                otneltobb++;    //valt + 1
            }
            listBox1.Items.Add(""); // ures sor h atlathato legyen
            listBox1.Items.Add("Ötnél több:" + otneltobb); // otnel tobb kiirat
        }
        // ---------------------legkisebb kikereses
        private void btn_legkisebb_Click(object sender, EventArgs e)
        {
            
            int minelem = golok[0];
            for (int i = 0; i <= db; i++)
            {
                if (golok[i] < minelem) 
                    minelem = golok[i]; //minelem legyen a legkisebb szam a tomben
            }

            listBox1.Items.Add(""); // ures sor h atlathato legyen
            listBox1.Items.Add("A legkisebb elem:" + minelem); // kiirat

        }
        // ---------------------ertekhatar (emlet/1)
        private void btn_xertehatarkiir_Click(object sender, EventArgs e)
        {
            try //kivetelkezeles 
            {
                int ertekhat = Convert.ToInt32(txt_ertekhatar.Text); // beolvas


                int xnelnagyobb = 0;

                for (int i = 0; i <= db; i++) //ertekhatnal tobb kikeres ua: alap/4 
                {
                    if (golok[i] > ertekhat)    // csere ertekhet valtra 
                        xnelnagyobb++;    //valt + 1
                }
                listBox1.Items.Add(""); // ures sor h atlathato legyen
                listBox1.Items.Add("Ötnél több:" + xnelnagyobb); // kiirat
                txt_ertekhatar.Clear(); //torol

            }
            catch (Exception ex)
            {
             MessageBox.Show($"Hiba az adatbevitel során: {ex.Message}", "Hiba", MessageBoxButtons.OK, MessageBoxIcon.Error); //kivetelkezeles; msg box hiba megjelenites
            }

        }
        // ---------------------statisztika
        private void btn_stat_Click(object sender, EventArgs e)
        {
           

            int nullaketto = 0;
            int haromot = 0;
            int otfelettiek = 0;
            listBox1.Items.Add(""); // ures sor h atlathato legyen
            for (int i = 0; i <= db; i++) //kiszamoljuk melyikbol mennyi van
            {
                if (golok[i] <= 2)
                    nullaketto++;
                else if (golok[i] <= 5)
                    haromot++;
                else
                    otfelettiek++;
            }
            //kiiratas resz
            listBox1.Items.Add(""); // ures sor h lathatobb legyen
            listBox1.Items.Add("0-2 közöttiek:" + nullaketto); 
            listBox1.Items.Add("");
            listBox1.Items.Add("3-5 közöttiek:" +haromot);
            listBox1.Items.Add("");
            listBox1.Items.Add("5 felettiek:" +otfelettiek);





        }
        // ---------------------sorbarendez
        private void btn_novekvo_Click(object sender, EventArgs e)
        {
            listBox2.Items.Clear(); // egész listadoboz tartalmának törlése
            int min;
            int csere;
            for (int i = 0; i < db; i++) //külső for ciklus
            {
                min = i;
                for (int k = i + 1; k <= db; k++) //belső for ciklus 
                {
                    if (golok[k] < golok[min])
                    {
                        min = k;
                    }


                }
                if (golok[min] < golok[i])
                {
                    csere = golok[min]; 
                    golok[min] = golok[i];
                    golok[i] = csere;
                }
                

            }

            for (int i = 0; i <= db; i++)
            {
                listBox2.Items.Add(golok[i]);
            }
        }
        // ---------------------random szám
        private void btn_random_Click(object sender, EventArgs e)
        {
            Random veletlen = new Random();
            for (int i = 0; i <= 10; i++)
            {
                db++;
                golok[db] = veletlen.Next(0, 8);
                listBox2.Items.Add(golok[db]);
            }
        }
        // ---------------------3nál nagyobb kiiratás 
        private void btn_haromfeletti_Click(object sender, EventArgs e)
        {
            listBox1.Items.Add("");
            for (int i = 0; i <= db; i++)
            {
                if (golok[i] > 3) //ha valamelyik elem nagyobb mint 3
                {
                    listBox1.Items.Add("3-nál nagyobb gólok:" + golok[i]);


                }
            }
        }

        private void btn_del_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < db; i++)
            {
                golok[i] = 0;
            }

            listBox1.Items.Clear();
            listBox2.Items.Clear();

        }
    }
}













//-----https://github.com/xyzBence
